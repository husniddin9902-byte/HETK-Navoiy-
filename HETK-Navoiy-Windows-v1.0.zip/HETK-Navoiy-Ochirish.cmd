@echo off
setlocal
title HETK Navoiy - Ochirish

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desktop=[Environment]::GetFolderPath('Desktop');" ^
  "$start=[Environment]::GetFolderPath('Programs');" ^
  "Remove-Item -LiteralPath (Join-Path $desktop 'HETK Navoiy.lnk') -Force -ErrorAction SilentlyContinue;" ^
  "Remove-Item -LiteralPath (Join-Path $start 'HETK Navoiy.lnk') -Force -ErrorAction SilentlyContinue;" ^
  "Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'HETK-Navoiy') -Recurse -Force -ErrorAction SilentlyContinue;"

echo HETK Navoiy yorligi ochirildi.
pause
