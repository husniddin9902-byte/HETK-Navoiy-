@echo off
setlocal
title HETK Navoiy - Ornatish

set "APPDIR=%LOCALAPPDATA%\HETK-Navoiy"
set "ICON=%APPDIR%\HETK-Navoiy.ico"
set "APPURL=https://husniddin9902-byte.github.io/HETK-Navoiy-/?source=windows-app"

if not exist "%APPDIR%" mkdir "%APPDIR%"
copy /Y "%~dp0HETK-Navoiy.ico" "%ICON%" >nul

set "BROWSER="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER=%LocalAppData%\Google\Chrome\Application\chrome.exe"

if not defined BROWSER (
  echo Microsoft Edge yoki Google Chrome topilmadi.
  echo Avval Edge yoki Chrome brauzerini ornating.
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ws=New-Object -ComObject WScript.Shell;" ^
  "$desktop=[Environment]::GetFolderPath('Desktop');" ^
  "$start=[Environment]::GetFolderPath('Programs');" ^
  "$s=$ws.CreateShortcut((Join-Path $desktop 'HETK Navoiy.lnk'));" ^
  "$s.TargetPath='%BROWSER%';$s.Arguments='--app=%APPURL%';$s.WorkingDirectory='%APPDIR%';$s.IconLocation='%ICON%,0';$s.Description='HETK Navoiy axborot tizimi';$s.Save();" ^
  "$s2=$ws.CreateShortcut((Join-Path $start 'HETK Navoiy.lnk'));" ^
  "$s2.TargetPath='%BROWSER%';$s2.Arguments='--app=%APPURL%';$s2.WorkingDirectory='%APPDIR%';$s2.IconLocation='%ICON%,0';$s2.Description='HETK Navoiy axborot tizimi';$s2.Save();"

if errorlevel 1 (
  echo HETK Navoiy ornatilmadi.
  pause
  exit /b 1
)

echo HETK Navoiy ish stoliga va Start menyusiga ornatildi.
start "" "%USERPROFILE%\Desktop\HETK Navoiy.lnk"
exit /b 0
